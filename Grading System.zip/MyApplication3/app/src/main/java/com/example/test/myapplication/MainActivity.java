package com.example.test.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText courseID, stdId,stdMarks;
    TextView courseID1,stdId1, stdMarks1, grades1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    courseID = findViewById(R.id.editText8);
    stdId  = findViewById(R.id.editText9);
    stdMarks = findViewById(R.id.editText7);
    courseID1= findViewById(R.id.textView23);
    stdId1 = findViewById(R.id.textView24);
    stdMarks1= findViewById(R.id.textView25);
    grades1 = findViewById(R.id.textView26);
    }

    public void show(View view) {

    String idnum=stdId.getText().toString();
    String courseid=courseID.getText().toString();
    String courseGrades= stdMarks.getText().toString();
    double score=Double.parseDouble(courseGrades);

    stdId1.setText(""+idnum);
    courseID1.setText(""+courseid);
    stdMarks1.setText(""+courseGrades);
    if (score >= 94 && score <=100){
        grades1.setText("A");
    }
    else if (score <= 93 && score >= 90){
            grades1.setText("A-");
        }
    else if (score <= 89 && score >= 87){
        grades1.setText("B+");
    }
    else if (score <= 86 && score >= 84){
        grades1.setText("B");
    }

    else if (score <= 83 && score >= 80){
        grades1.setText("B-");
    }

    else if (score <= 79 && score >= 77){
        grades1.setText("C+");
    }

    else if (score <= 76 && score >= 74){
        grades1.setText("C");
    }

    else if (score <= 73 && score >= 70){
        grades1.setText("C-");
    }

    else if (score <= 69 && score >= 67){
        grades1.setText("D+");
    }

    else if (score <= 66 && score >= 60){
        grades1.setText("D");
    }
    else {grades1.setText("F");}

    }
}
